# Dolch · cross-application starter

An exploratory extension of the original Dolch palette, prepared for Ashlynne. This is not an official upstream release or an installed theme. The original dark blue and upstream Alter palettes anchor the study; Violet, Green and Rose explore additional lead colors at the user’s request. New flavors are proposals, not upstream themes. Light palettes are retained as reference.

## Open this first

Open `preview.html` in a browser. It is self-contained and uses no external fonts, scripts or services. The preview shows a proposed general-purpose UI, semantic swatches, alternative lead-color studies and generated ramps. The examples are design specimens, not working application integrations.

## Files and tweaking

- `palette.json`: compact original-dark primitives, 32 proposed roles with provenance/usage notes, and ANSI proposal
- `dolch.css`: original-blue ramp entries and semantic aliases as CSS custom properties
- `flavor-studies.json`: Blue, original Alter, Violet, Green and Rose parameters, ramps, roles and per-flavor contrast checks
- `flavors.css`: all five flavor selectors; load after `dolch.css`, set `data-dolch-flavor="violet"` (or blue/alter/green/rose) on the root element
- `build_flavors.py`: regenerate flavor studies and CSS from its explicit parameters, using Python only
- `terminal-proposal.json`: portable values to map into a terminal’s own configuration
- `contrast-and-roles.json`: measured contrast and role restrictions
- `reference/`: original VS Code JSON, full four-flavor reproduction, source snapshot and reproduction script

Edit role values in `palette.json`, then run `python3 build_tokens.py` to regenerate CSS and terminal JSON. The self-contained preview embeds its own snapshot and does not automatically load edited files; it is a review specimen, not a live theme editor. The original generator parameters and formulas are preserved in the reference JSON/script if you later want to change the color generation itself. No npm packages are required for these exports.

## The organizing idea

1. **Primitives:** original named color ramps, grades 0–10. Keep the generated hex values unchanged.
2. **Roles:** assign a small set of those values to canvas, panels, text, interactions, status and selection. Ports should consume roles rather than improvise a new blue for each control.
3. **Adapters:** map roles to each application's theme keys. CSS is included as a starting adapter; terminal ANSI is a proposed mapping, not a tested terminal port.

Keep most of an interface charcoal and gray. Cyan-blue is the main interaction color. Teal is a supporting accent; the full hue ring is available for status, diagrams, syntax, diffs and tags. Having twelve hues does not mean using twelve equal-weight UI accents. Retain text/icons alongside statuses and chart labels: color alone is not enough.

## What is faithful and what is new

The original canvas (#101416), panels (#222527), raised surfaces (#343739), text (#B0B4B7), blue accent (#00ACCE) and bright cyan (#7BF2FF) are unchanged. The neutral ramp is subtly cool, not fully blue. Syntax mappings in `reference/vscode-original.json` are the published originals; the wider UI examples do not propose replacing them with rainbow syntax.

Semantic aliases and terminal assignments are new proposals. Primary filled buttons use dark text for legibility: the upstream #DFE3E6 label on #0096B7 measures about 2.69:1, while #101416 on #00ACCE measures about 6.87:1. A decorative border need not meet text contrast, but a border that is the only way to identify a control requires separate checking. The preview is not a blanket accessibility certification.

## Five dark flavor studies

Blue and Alter use exact upstream generated palettes. Violet, Green and Rose are new parameter choices using the same generation method, each with a subtle near-neutral surface tint, a lead accent and a supporting accent. The proposed three keep the Blue flavor’s diagnostic hue ring so changing the interface accent does not randomly change success/error meanings. Alter retains its original ring.

The lead colors are Blue #00ACCE, Alter #CA933C, Violet #A194D8, Green #67AC7A and Rose #DC839F. All five have 21 measured essential foreground/background pairs in the flavor JSON; these checks are narrower than a complete UI accessibility audit.

Edit the variant parameters in `build_flavors.py` and rerun it to regenerate flavor JSON/CSS. This is separate from editing base `palette.json`; the preview embeds a fixed comparison snapshot and must be regenerated separately to show those edits.

## Generator details worth preserving

Dolch has 17 ramps of 11 entries, including duplicated foreground/background ramps in the dark flavor. Its 12-color ring uses 30-degree hue intervals. It is CIE LCh(ab) with a D65 white point, not OKLCH and not a direct CSS `lch()` drop-in (which uses D50). The original conversion clips out-of-sRGB channel values; high-grade colors therefore do not retain perfectly equal perceived lightness/chroma. Preserve final hex values for faithful ports. Any gamut-mapped redesign should be a separately reviewed future change.

`reference/all-generated-palettes.json` contains the independently reproduced full output for all four variants, provenance, clipping flags and mappings back to published VS Code colors. All published colors were checked against the reproduction. `reference/reproduce_palette.py` uses only Python's standard library and the included inspected source snapshot. Running it writes regenerated reference JSON alongside itself; it does not install or modify applications.

## Keep the next step small

Try one real port after reviewing the sampler, ideally the terminal or another daily-use application. Check ordinary text, hover/focus/selected states, diagnostics and terminal black/bright-black output. Use the flavor studies to choose a direction before expanding into many application ports.

## Sources and attribution

- Original Dolch by Renzhi Li (Belleve Invis): https://github.com/be5invis/vscode-theme-dolch/tree/cf3817311b30d3c21a60ebb0b250d18386e66a30
- Catppuccin organization reference: https://github.com/catppuccin/catppuccin/blob/main/docs/style-guide.md
- Madoromi organization reference: https://github.com/the-moonwitch/madoromi/blob/main/palettes/style-guide.md

Original Dolch material is MIT licensed; its copyright and permission notice are included in `LICENSE-Dolch.txt`. Palette/role organization in this starter is a proposal, not an upstream endorsement. Catppuccin and Madoromi informed the organization, not the colors.

## Validation and preview limits

The core contrast calculations were independently rechecked for all five flavors (21 selected pairs each). HTML JavaScript syntax, embedded palette data, referenced element IDs, and offline dependency checks passed. Browser layout and interactive behavior were not runtime-verified because the available browser environment could not open the sampler. The supplied PNGs are separately rendered palette studies, not screenshots of the HTML. Open the HTML locally to review its layout and interactions.

# Solai — Windows Terminal

One native scheme object, not a replacement settings.json. This format has no independent selected-text or cursor-text colour.

- Unzip the download and locate its scheme .json file; keep the accompanying license notices. Open Windows Terminal → Settings → Open JSON file. Store installations normally use %LOCALAPPDATA%\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json; unpackaged installations use %LOCALAPPDATA%\Microsoft\Windows Terminal\settings.json.
- Copy the downloaded object into the existing top-level schemes array, keeping other schemes and valid commas. Do not replace settings.json with this file.
- In Settings choose the desired profile → Appearance → Color scheme → Solai Tide Dark (or your imported name), then Save. Alternatively set that profile’s colorScheme to the exact scheme name. Your default profile and command line remain unchanged.

- Solai Tide Dark: solai-tide-dark.json
- Solai Tide Light: solai-tide-light.json
- Solai Ember Dark: solai-ember-dark.json
- Solai Ember Light: solai-ember-light.json
- Solai Dusk Dark: solai-dusk-dark.json
- Solai Dusk Light: solai-dusk-light.json
- Solai Viridian Dark: solai-viridian-dark.json
- Solai Viridian Light: solai-viridian-light.json
- Solai Bloom Dark: solai-bloom-dark.json
- Solai Bloom Light: solai-bloom-light.json

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.

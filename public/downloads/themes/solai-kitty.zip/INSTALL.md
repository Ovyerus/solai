# Solai — Kitty

Colour-only include for Kitty; fonts, tabs, layout and shell settings remain yours.

- Save the file under ~/.config/kitty/themes/ on macOS or Linux (or the themes directory under your KITTY_CONFIG_DIRECTORY).
- Add include themes/solai-tide-dark.conf to your existing kitty.conf, replacing the filename with your chosen variant. Place it after other colour settings you want it to override.
- Reload the config with Ctrl+Shift+F5 on Linux or Control+Command+, on macOS. Other explicit colour settings after the include can override this theme.

- Solai Tide Dark: solai-tide-dark.conf
- Solai Tide Light: solai-tide-light.conf
- Solai Ember Dark: solai-ember-dark.conf
- Solai Ember Light: solai-ember-light.conf
- Solai Dusk Dark: solai-dusk-dark.conf
- Solai Dusk Light: solai-dusk-light.conf
- Solai Viridian Dark: solai-viridian-dark.conf
- Solai Viridian Light: solai-viridian-light.conf
- Solai Bloom Dark: solai-bloom-dark.conf
- Solai Bloom Light: solai-bloom-light.conf

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.

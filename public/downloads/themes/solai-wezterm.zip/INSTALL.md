# Solai — WezTerm

Native colour-scheme TOML, not an executable Lua configuration.

- On macOS or Linux save the file in ~/.config/wezterm/colors/. On Windows use the colors directory beside wezterm.exe, or a directory already listed in color_scheme_dirs.
- In your existing wezterm.lua, set config.color_scheme = "Solai Tide Dark" using the exact name from the file’s [metadata] section, and retain your existing returned config table.
- WezTerm reloads configuration automatically. Explicit config.colors overrides still take precedence; multiplexed sessions use the multiplexer server’s scheme configuration.

- Solai Tide Dark: solai-tide-dark.toml
- Solai Tide Light: solai-tide-light.toml
- Solai Ember Dark: solai-ember-dark.toml
- Solai Ember Light: solai-ember-light.toml
- Solai Dusk Dark: solai-dusk-dark.toml
- Solai Dusk Light: solai-dusk-light.toml
- Solai Viridian Dark: solai-viridian-dark.toml
- Solai Viridian Light: solai-viridian-light.toml
- Solai Bloom Dark: solai-bloom-dark.toml
- Solai Bloom Light: solai-bloom-light.toml

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.

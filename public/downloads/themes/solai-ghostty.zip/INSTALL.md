# Solai — Ghostty

Native colour-only theme with cursor, opaque selection and the exact 16 ANSI slots.

- Save the .conf file in $XDG_CONFIG_HOME/ghostty/themes/ (normally ~/.config/ghostty/themes/ on macOS and Linux). Create the themes directory if needed.
- In your existing Ghostty config, set theme = solai-tide-dark.conf, replacing the name with the exact downloaded filename, including .conf. An absolute path also works. Do not replace the rest of your config.
- Reload Ghostty configuration to apply. Existing explicit colour overrides in your config take precedence over theme values.

- Solai Tide Dark: solai-tide-dark.conf
- Solai Tide Light: solai-tide-light.conf
- Solai Ember Dark: solai-ember-dark.conf
- Solai Ember Light: solai-ember-light.conf
- Solai Dusk Dark: solai-dusk-dark.conf
- Solai Dusk Light: solai-dusk-light.conf
- Solai Viridian Dark: solai-viridian-dark.conf
- Solai Viridian Light: solai-viridian-light.conf
- Solai Bloom Dark: solai-bloom-dark.conf
- Solai Bloom Light: solai-bloom-light.conf

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.

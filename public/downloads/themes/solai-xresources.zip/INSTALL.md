# Solai — Xresources / xterm

XTerm-scoped X11 resources with the exact ANSI palette and opaque selection. Other terminal emulators may use different resource names; xterm controls cursor text itself.

- Save the file under ~/.config/solai/ on an X11 system, then add #include ".config/solai/solai-tide-dark.Xresources" to ~/.Xresources, using your chosen filename. The quoted path resolves relative to ~/.Xresources.
- Merge your existing resource file with xrdb -merge ~/.Xresources, then open a new xterm. Keep other resources; do not use xrdb -load, which replaces the resource database.
- These resources target the XTerm application class only. More-specific existing XTerm resources and application-set colours may override them. A Wayland-native terminal does not consume Xresources.

- Solai Tide Dark: solai-tide-dark.Xresources
- Solai Tide Light: solai-tide-light.Xresources
- Solai Ember Dark: solai-ember-dark.Xresources
- Solai Ember Light: solai-ember-light.Xresources
- Solai Dusk Dark: solai-dusk-dark.Xresources
- Solai Dusk Light: solai-dusk-light.Xresources
- Solai Viridian Dark: solai-viridian-dark.Xresources
- Solai Viridian Light: solai-viridian-light.Xresources
- Solai Bloom Dark: solai-bloom-dark.Xresources
- Solai Bloom Light: solai-bloom-light.Xresources

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.

# Solai — Alacritty

Importable TOML containing only primary, cursor, selection and ANSI colours.

- Save the file under ~/.config/alacritty/themes/ on macOS or Linux, or %APPDATA%\alacritty\themes\ on Windows.
- Add the chosen file to the import array in the existing [general] table of alacritty.toml, for example import = ["themes/solai-tide-dark.toml"]. Merge with existing imports; do not duplicate the table or replace the config.
- Imports resolve relative to alacritty.toml; its own colour settings override imported values. Alacritty normally reloads changes automatically; otherwise restart it.

- Solai Tide Dark: solai-tide-dark.toml
- Solai Tide Light: solai-tide-light.toml
- Solai Ember Dark: solai-ember-dark.toml
- Solai Ember Light: solai-ember-light.toml
- Solai Dusk Dark: solai-dusk-dark.toml
- Solai Dusk Light: solai-dusk-light.toml
- Solai Viridian Dark: solai-viridian-dark.toml
- Solai Viridian Light: solai-viridian-light.toml
- Solai Bloom Dark: solai-bloom-dark.toml
- Solai Bloom Light: solai-bloom-light.toml

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.

# Solai — macOS Terminal

Colour-only native profile with real sRGB NSColor keyed archives. Terminal controls selected-text and cursor-text colours itself.

- Keep the .terminal file anywhere convenient on your Mac. In Terminal → Settings → Profiles, use the action menu → Import… and select it, or drag it from Finder into the profile list.
- Choose the imported Solai profile from Shell → New Window or Shell → New Tab. Importing does not make it the default profile and does not modify your existing profiles.
- The imported profile supplies colours only; other properties inherit Terminal’s defaults, not custom settings from another profile. Adjust those in the new profile if needed. No shell command, font or window dimensions are included.

- Solai Tide Dark: solai-tide-dark.terminal
- Solai Tide Light: solai-tide-light.terminal
- Solai Ember Dark: solai-ember-dark.terminal
- Solai Ember Light: solai-ember-light.terminal
- Solai Dusk Dark: solai-dusk-dark.terminal
- Solai Dusk Light: solai-dusk-light.terminal
- Solai Viridian Dark: solai-viridian-dark.terminal
- Solai Viridian Light: solai-viridian-light.terminal
- Solai Bloom Dark: solai-bloom-dark.terminal
- Solai Bloom Light: solai-bloom-light.terminal

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.

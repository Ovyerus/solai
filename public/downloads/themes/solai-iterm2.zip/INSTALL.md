# Solai — iTerm2

Native sRGB colour preset; does not replace a profile or its fonts and commands.

- Keep the .itermcolors file anywhere convenient on your Mac. In iTerm2 open Settings → Profiles, choose your existing profile, then Colors → Color Presets… → Import….
- Select the downloaded file, then choose its filename-based preset from Color Presets…. If separate light/dark colours are enabled, first choose the mode you want to edit.
- Enable Use custom color for selected text to use the exported selected-text colour. Existing minimum-contrast, cursor-boost and context-aware cursor options can alter displayed colours; the preset does not change those preferences.

- Solai Tide Dark: solai-tide-dark.itermcolors
- Solai Tide Light: solai-tide-light.itermcolors
- Solai Ember Dark: solai-ember-dark.itermcolors
- Solai Ember Light: solai-ember-light.itermcolors
- Solai Dusk Dark: solai-dusk-dark.itermcolors
- Solai Dusk Light: solai-dusk-light.itermcolors
- Solai Viridian Dark: solai-viridian-dark.itermcolors
- Solai Viridian Light: solai-viridian-light.itermcolors
- Solai Bloom Dark: solai-bloom-dark.itermcolors
- Solai Bloom Light: solai-bloom-light.itermcolors

The sixteen ANSI slots preserve conventional black/white and normal/bright banks. Some slots have low contrast as foreground text, particularly white in light mode. Applications choose their own ANSI/true-colour usage. Schemes do not change shell prompts, fonts or keyboard settings.

Original Dolch palettes: Renzhi Li (Belleve Invis). https://github.com/be5invis/vscode-theme-dolch
Tide retains upstream Blue primitives; Ember uses original Alter custom ramps with the shared Blue base. Dusk, Viridian, Bloom and the application mappings are Solai studies.

This MIT license covers the Solai application theme ports and their port mappings only. It does not relicense the website, artwork, fonts or other palette exports.
See LICENSE-Themes.txt and LICENSE-Dolch.txt.
